package com.mubashar.employmanager;

public class OtherValues {

    String imageIdentifier, imageLink, latitude, longitude, timeAndDate, placeName;

    public String getImageIdentifier() {
        return imageIdentifier;
    }

    public String getImageLink() {
        return imageLink;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setImageIdentifier(String imageIdentifier) {
        this.imageIdentifier = imageIdentifier;
    }

    public void setImageLink(String imageLink) {
        this.imageLink = imageLink;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getTimeAndDate() {
        return timeAndDate;
    }

    public void setTimeAndDate(String timeAndDate) {
        this.timeAndDate = timeAndDate;
    }

    public String getPlaceName() {
        return placeName;
    }

    public void setPlaceName(String placeName) {
        this.placeName = placeName;
    }
}
